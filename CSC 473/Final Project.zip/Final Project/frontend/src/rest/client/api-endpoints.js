export const API_ENDPOINTS = {
    login: "/auth/login",
    register: "/auth/register",
    blog: "/blog",
    users: "/users",
    uploads: "/upload/"

}